﻿namespace XGame.Domain.Enum
{
    public enum EnumSituacaoJogador
    {
        EmAnalise = 0,
        Ativo = 1,
        Bloqueado = 2
    }
}
