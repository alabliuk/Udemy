﻿namespace XGame.Domain.Arguments.Jogador
{
    public class AutenticarJogadorRequest
    {
        public string Email { get; set; }

        public string Senha { get; set; }
    }
}
