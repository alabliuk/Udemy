﻿namespace XGame.Domain.Arguments.Plataforma
{
    public class AdicionarPlataformaRequest
    {
        public string Nome { get; set; }
    }
}
