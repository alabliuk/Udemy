﻿namespace XGame.Domain.Interfaces.Arguments
{
    public interface IResponse
    {
    }
}
