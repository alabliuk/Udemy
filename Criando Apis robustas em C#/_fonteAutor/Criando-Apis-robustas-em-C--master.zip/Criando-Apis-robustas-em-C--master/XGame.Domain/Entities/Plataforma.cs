﻿using System;

namespace XGame.Domain.Entities
{
    public class Plataforma
    {
        public Guid id { get; set; }

        public string Nome { get; set; }
    }
}
