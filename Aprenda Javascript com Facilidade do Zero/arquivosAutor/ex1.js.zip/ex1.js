
console.log("Questão 1)");

console.log("O arquivo 'ex1.js' está funcionando");

console.log('--------------------');

console.log("Questão 2)");

var nome = "Ivan";
var ano_nasc = 1986;
var ano_atual = 2018;
var idade = ano_atual - ano_nasc;

console.log("Olá, eu me chamo " + nome + ", tenho " + idade + " anos e estou estudando Javascript");

console.log('--------------------');


console.log("Questão 3)");

var aluno = "Pedro";
var matr = "465353";
var n1 = 9;
var n2 = 8;

var media = (n1 + n2) / 2;

console.log("O aluno " + aluno + ", matrícula " + matr + ", obteve a média final " + media);

console.log('--------------------');


console.log("Questão 4)");

var telefone = "98122985599";

console.log("Resultado do teste: " + (telefone.length == 9));

console.log('--------------------');

console.log("Questão 5)");

console.log( Math.pow(32,6) );

console.log('--------------------');

console.log("Questão 7)");

var quantidade = "25";
var numero = 6;
var pressao;
var temperatura = 40;
temperatura = null;

console.log(quantidade += quantidade);
console.log( (7+5) / numero + 2 ); 
console.log(pressao);
console.log(temperatura);
console.log(typeof pressao);
console.log(typeof temperatura);

console.log('--------------------');



console.log("Questão 8)");
var idade = 65;

console.log(idade != 65);
console.log(idade >= 65); 
console.log("65" == idade);
console.log(65 !== idade);
console.log(typeof (idade > 60));
console.log(typeof (idade > 70));




