let userController = new UserController("form-user-create", "form-user-update", "table-users");

