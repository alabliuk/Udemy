// switch
let cor = "azul";

switch (cor) {

    case "verde":
        console.log("siga");
        break;

    case "amarelo":
        console.log("atenção");
        break;

    case "vermelho":
        console.log("pare");
        break;

    default:
        console.log("não sei");

}

// orientação a objetos hoje
class celular {

    constructor() {

        this.cor = "prata";

    };

    ligar() {

        console.log("uma ligação");
        return "ligando";

    }

}

let objeto = new celular();

console.log(objeto.ligar());