class FileInfo {

    constructor(){}

    loadFromJSON(data){

        

    }

}