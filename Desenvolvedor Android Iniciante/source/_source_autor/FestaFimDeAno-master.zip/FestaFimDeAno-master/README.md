# Festa de Final de Ano

O aplicativo Festa de Final de Ano é o segundo aplicativo criado no curso [Desenvolvedor Android Iniciante](
https://www.udemy.com/desenvolvedor-android-iniciante/). Este aplicativo mostra quantos dias faltam para o final do ano e confirma sua presença na melhor festa que já existiu.

Além disso, nele fazemos o uso de Intent para navegação entre activities, eventos de click, inclusão de imagens, uso do SharedPreferences para armazenar dados localmente e muito mais!

Fique à vontade para baixar o código, rodar o aplicativo e se tiver alguma dúvida, basta entrar em contato conosco através do site [DevMasterTeam](http://www.devmasterteam.com/#contact) e mesmo que não esteja no curso, teremos prazer em atendê-lo!

[![](https://github.com/DevMasterTeam/FestaFimDeAno/blob/master/presentation/Image1.png)](https://github.com/DevMasterTeam/FestaFimDeAno/blob/master/presentation/Image1.png)